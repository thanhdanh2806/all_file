var so = 83 ;
console.log(so);
var sohangchuc = so / 10 ;
console.log(sohangchuc);
var sodonvi = so % 10 ;
console.log(sodonvi);
var sum = [parseInt(sohangchuc)+parseInt(sodonvi)]
console.log ("tong : " + sum);