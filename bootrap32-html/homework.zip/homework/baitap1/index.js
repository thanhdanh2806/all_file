
function handleLogin() {
    var soday = document.getElementById("money");
    var sotienla =  soday.value * 100 ;
    // console.log("sotienla : ", sotienla , ".000 vnd");
    // document.write('sotienla :  ' + sotienla + '.000 vnd');
    alert('sotienla :  ' + sotienla + ' vnd');
}