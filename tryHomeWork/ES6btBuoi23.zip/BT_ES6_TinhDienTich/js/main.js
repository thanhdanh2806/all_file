function dom(selector) {
  return document.querySelector(selector);
}

dom("#areaSquare").addEventListener("click", () => {
  const side = +dom("#side").value;
  const sizeX = +dom("#squareX").value;
  const sizeY = +dom("#squareY").value;
  const bgColor = dom("#squareColor").value;

  const square = new Square("Square", bgColor, sizeX, sizeY, side);
  square.calcArea();
  square.draw();
});
