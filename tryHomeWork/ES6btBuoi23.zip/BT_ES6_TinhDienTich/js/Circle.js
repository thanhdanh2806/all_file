class Circle extends Shape {
  constructor(name, bgColor, sizeX, sizeY, radius) {
    super(name, bgColor, sizeX, sizeY);
    this.radius = radius;
  }

  calcArea() {
    this.area = Math.PI * this.radius ** 2;
  }
}
