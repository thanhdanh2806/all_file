class Reactangle extends Shape {
  constructor(name, bgColor, sizeX, sizeY, width, length) {
    super(name, bgColor, sizeX, sizeY);
    this.width = width;
    this.length = length;
  }

  calcArea() {
    this.area = this.length * this.width;
  }
}
