// class cha
class Shape {
  constructor(name, bgColor, sizeX, sizeY) {
    this.name = name;
    this.bgColor = bgColor;
    this.sizeX = sizeX;
    this.sizeY = sizeY;
    this.area = 0;
  }

  draw() {
    const html = `
      <div style="width: ${this.sizeX}px; height: ${this.sizeY}px; background-color: ${this.bgColor}">
        <h3>${this.name}</h3>
        <p>Area: ${this.area}</p>
      </div>
    `;

    document.getElementById("main").innerHTML = html;
  }
}
