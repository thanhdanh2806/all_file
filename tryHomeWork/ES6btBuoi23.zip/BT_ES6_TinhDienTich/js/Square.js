class Square extends Shape {
  constructor(name, bgColor, sizeX, sizeY, side) {
    super(name, bgColor, sizeX, sizeY);
    this.side = side;
  }

  calcArea() {
    this.area = this.side ** 2;
  }
}
